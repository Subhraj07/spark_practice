from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

with open('session.txt', 'r') as f:
    session = int(f.readlines()[0])

df = spark.sql("select * from bigdata_usecase.load_clickstream")
df = df.withColumn("session_id", lit(session))

new_df = df.select("session_id", "time_stamp", "user_id",
                   year("time_stamp").alias('year'),
                   month("time_stamp").alias('month'),
                   dayofmonth("date").alias('day')
                   )

spark.conf.set("hive.exec.dynamic.partition", "true")
spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
new_df.write.insertInto("bigdata_usecase.clickstream")

with open('session.txt', 'w') as f:
    f.write(str(session + 1))

spark.stop()
