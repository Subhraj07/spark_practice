from datetime import datetime
import random
import time

now = datetime.now()
dt_string = now.strftime("%Y-%m-%dT%H:%M:%SZ")

lst = [1, 4, 5, 2, 7]

for i in range(5):
    with open("datasets/clickstream{}.csv".format(i),
              mode='a') as file:
        for j in range(10):
            file.write('%s,%s\n' % (dt_string, "u" + str(random.choice(lst))))
            time.sleep(1)

# Data comes to load_clickstream table in hive
