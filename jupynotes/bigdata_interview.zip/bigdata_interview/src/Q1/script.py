dict = {}
with open('datasets/q1.txt', mode='r') as fp:
    for i, line in enumerate(fp):
        if (line.split(',')[0] != "Name"):
            dict[line.split(',')[0] + " " + line.split(',')[1]] = line.split(',')[2]

lst = []
for k, v in dict.items():
    lst.append(k.split(" ")[0] + "," + k.split(" ")[1] + "," + v)

file1 = open("datasets/MyFile.txt", "a")
file1.writelines(lst)
file1.close()
